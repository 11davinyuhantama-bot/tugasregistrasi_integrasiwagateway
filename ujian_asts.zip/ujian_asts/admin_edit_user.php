<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') { header('Location: /ujian_asts/login.php'); exit; }
require_once __DIR__ . '/koneksi.php';
$adminId=(int)$_SESSION['user_id'];
$check=$conn->prepare('SELECT role FROM users WHERE id=?'); $check->bind_param('i',$adminId); $check->execute();
if (($check->get_result()->fetch_assoc()['role']??'')!=='admin') { session_unset(); session_destroy(); header('Location: /ujian_asts/login.php'); exit; }
$targetId=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);
if (!$targetId || $targetId===$adminId) { $_SESSION['admin_notice']='Akun tersebut tidak dapat diedit.'; header('Location: /ujian_asts/admin_dashboard.php'); exit; }
function ah($value){return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']??''); $nisn=trim($_POST['nisn']??''); $ttl=trim($_POST['ttl']??'');
    $gender=trim($_POST['gender']??''); $email=trim($_POST['email']??''); $phone=preg_replace('/\D+/','',trim($_POST['phone']??''));
    $phone=preg_replace('/^(?:62|0)/','',$phone); $phone='62'.$phone; $address=trim($_POST['address']??'');
    if (!$name||!$nisn||!$ttl||!in_array($gender,['Laki-laki','Perempuan'],true)||!filter_var($email,FILTER_VALIDATE_EMAIL)||!preg_match('/^62[0-9]{9,13}$/',$phone)||!$address) {
        $_SESSION['admin_notice']='Periksa kembali data profil dan nomor WhatsApp.'; header('Location: /ujian_asts/admin_edit_user.php?id='.$targetId); exit;
    }
    $stmt=$conn->prepare("UPDATE users SET name=?,nisn=?,ttl=?,gender=?,email=?,phone=?,address=? WHERE id=? AND role='user'");
    $stmt->bind_param('sssssssi',$name,$nisn,$ttl,$gender,$email,$phone,$address,$targetId);
    try { $stmt->execute(); } catch (mysqli_sql_exception $error) { $_SESSION['admin_notice']='Perubahan gagal disimpan (kode '.$error->getCode().').'; header('Location: /ujian_asts/admin_edit_user.php?id='.$targetId); exit; }
    if ($stmt->affected_rows < 0) { $_SESSION['admin_notice']='Perubahan gagal disimpan.'; header('Location: /ujian_asts/admin_edit_user.php?id='.$targetId); exit; }
    require_once __DIR__ . '/admin_notification_helper.php';
    catatNotifikasiAdmin($conn, $targetId, (string)$_SESSION['username'], (string)$_SESSION['username'], 'admin_edit', "mengubah profil pengguna {$name}.");
    require_once __DIR__ . '/fonnte.php';
    [, $delivery]=kirimPesanFonnte($phone,pesanAkunDieditAdmin($name));
    $_SESSION['admin_notice']='Profil pengguna berhasil diperbarui. '.$delivery;
    header('Location: /ujian_asts/admin_dashboard.php'); exit;
}
$stmt=$conn->prepare("SELECT id,name,nisn,ttl,gender,email,phone,address,username FROM users WHERE id=? AND role='user'");
$stmt->bind_param('i',$targetId); $stmt->execute(); $user=$stmt->get_result()->fetch_assoc();
if (!$user) { $_SESSION['admin_notice']='Akun pengguna tidak ditemukan.'; header('Location: /ujian_asts/admin_dashboard.php'); exit; }
$notice=$_SESSION['admin_notice']??''; unset($_SESSION['admin_notice']);
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Edit Pengguna | ASTS</title><style>*{box-sizing:border-box}body{margin:0;background:#f5f6fb;color:#172033;font:14px Arial,sans-serif}.wrap{width:min(820px,calc(100% - 30px));margin:35px auto}.top,.card{background:#fff;border:1px solid #edf0f6;border-radius:16px;box-shadow:0 16px 40px #1d264b0c}.top{padding:17px 21px;display:flex;justify-content:space-between}.top a{color:#5b55e7;text-decoration:none}.card{margin-top:18px;padding:25px}.card h1{margin:0 0 6px;font-size:24px}.muted{color:#77819a;margin:0 0 20px}.notice{background:#fff7e7;color:#8b6416;border-radius:9px;padding:12px;margin-bottom:15px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}label{display:grid;gap:7px;font-size:12px;font-weight:700;color:#566078}input,select,textarea{font:inherit;font-weight:400;font-size:13px;padding:11px 12px;width:100%;border:1px solid #e0e4ee;border-radius:9px;color:#172033}textarea{min-height:90px;resize:vertical}.wide{grid-column:1/-1}.actions{display:flex;justify-content:flex-end;gap:9px;margin-top:20px}button,.cancel{border:0;border-radius:9px;padding:11px 16px;font-weight:700;cursor:pointer;text-decoration:none}.save{background:#5b55e7;color:#fff}.cancel{background:#f0f1f7;color:#59637a}@media(max-width:600px){.grid{grid-template-columns:1fr}.wide{grid-column:auto}.card{padding:19px}}</style></head><body><main class="wrap"><header class="top"><strong>ASTS · Admin · Edit Pengguna</strong><a href="/ujian_asts/admin_dashboard.php">Kembali ke dashboard</a></header><section class="card"><h1>Edit akun pengguna</h1><p class="muted">Simpan perubahan untuk mengirim pemberitahuan ke WhatsApp pengguna.</p><?php if($notice):?><div class="notice"><?=ah($notice)?></div><?php endif;?><form method="post" action="/ujian_asts/admin_edit_user.php"><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><div class="grid">
<label>Nama lengkap<input name="name" maxlength="100" value="<?=ah($user['name'])?>" required></label><label>Username<input value="<?=ah($user['username'])?>" disabled></label>
<label>NISN<input name="nisn" maxlength="20" value="<?=ah($user['nisn'])?>" required></label><label>Tempat, tanggal lahir<input name="ttl" maxlength="100" value="<?=ah($user['ttl'])?>" required></label>
<label>Jenis kelamin<select name="gender" required><option value="Laki-laki" <?=$user['gender']==='Laki-laki'?'selected':''?>>Laki-laki</option><option value="Perempuan" <?=$user['gender']==='Perempuan'?'selected':''?>>Perempuan</option></select></label><label>Email<input type="email" name="email" maxlength="100" value="<?=ah($user['email'])?>" required></label>
<label class="wide">Nomor WhatsApp<input type="tel" name="phone" value="<?=ah($user['phone']??'')?>" required></label><label class="wide">Alamat<textarea name="address" required><?=ah($user['address'])?></textarea></label></div><div class="actions"><a class="cancel" href="/ujian_asts/admin_dashboard.php">Batal</a><button class="save" type="submit">Simpan & kirim WhatsApp</button></div></form></section></main></body></html>
