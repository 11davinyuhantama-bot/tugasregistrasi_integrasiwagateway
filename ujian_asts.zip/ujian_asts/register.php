<?php
session_start();
if (isset($_SESSION['user_id'])) { header('Location: /ujian_asts/index.php'); exit; }
$error = $_SESSION['register_error'] ?? '';
unset($_SESSION['register_error']);
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Daftar Akun ASTS</title>
<style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f1f5f9;font:15px Arial;color:#172033}.card{width:min(560px,100%);background:white;padding:32px;border-radius:20px;box-shadow:0 16px 50px #17203318}h1{margin:0 0 8px}p{color:#64748b}form{display:grid;grid-template-columns:1fr 1fr;gap:14px}label{display:grid;gap:6px;font-size:13px;font-weight:bold}input,select,textarea{font:inherit;padding:11px;border:1px solid #cbd5e1;border-radius:9px;width:100%}.wide{grid-column:1/-1}button{padding:13px;border:0;border-radius:9px;background:#4f46e5;color:white;font-weight:bold;cursor:pointer}.error{padding:12px;background:#fff1f2;color:#be123c;border-radius:8px;margin:16px 0}a{color:#4f46e5}@media(max-width:500px){form{grid-template-columns:1fr}.wide{grid-column:auto}}</style></head><body><main class="card"><h1>Buat akun</h1><p>Daftar untuk membuat halaman profil pribadi.</p>
<?php if ($error): ?><div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<form action="/ujian_asts/proses_register.php" method="post">
<label>Nama lengkap<input name="name" maxlength="100" required></label><label>Username<input name="username" minlength="3" maxlength="50" autocomplete="username" required></label>
<label>NISN<input name="nisn" maxlength="20" required></label><label>Tempat, tanggal lahir<input name="ttl" maxlength="100" required></label>
<label>Jenis kelamin<select name="gender" required><option value="">Pilih</option><option>Laki-laki</option><option>Perempuan</option></select></label><label>Email<input type="email" name="email" maxlength="100" required></label>
<label class="wide">Nomor WhatsApp<input type="tel" name="phone" placeholder="Contoh: 081234567890" minlength="10" maxlength="20" autocomplete="tel" required><small>Nomor ini akan menerima pesan WhatsApp setelah akun berhasil didaftarkan.</small></label>
<label class="wide">Alamat<textarea name="address" rows="3" required></textarea></label><label class="wide">Password<input type="password" name="password" minlength="8" autocomplete="new-password" required></label>
<button class="wide" type="submit">Daftar</button></form><p>Sudah punya akun? <a href="/ujian_asts/login.php">Login</a></p></main></body></html>
