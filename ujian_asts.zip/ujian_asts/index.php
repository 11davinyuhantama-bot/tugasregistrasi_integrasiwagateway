<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /ujian_asts/login.php'); exit; }
if (($_SESSION['role'] ?? 'user') === 'admin') { header('Location: /ujian_asts/admin_dashboard.php'); exit; }
require_once __DIR__ . '/koneksi.php';
$id = (int)$_SESSION['user_id'];
$stmt = $conn->prepare('SELECT name, nisn, ttl, gender, email, phone, address, username FROM users WHERE id=?');
$stmt->bind_param('i', $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) { session_unset(); session_destroy(); header('Location: /ujian_asts/login.php'); exit; }
$notice = $_SESSION['account_notice'] ?? '';
unset($_SESSION['account_notice']);
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
$parts = preg_split('/\s+/', trim((string)$user['name']));
$initials = strtoupper(substr($parts[0] ?? '?', 0, 1) . (count($parts) > 1 ? substr(end($parts), 0, 1) : ''));
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Profil Saya | ASTS</title>
  <style>
    :root{--ink:#172033;--muted:#77819a;--line:#e8ebf3;--purple:#5b55e7;--shadow:0 18px 48px rgba(29,38,75,.07)}
    *{box-sizing:border-box}body{margin:0;background:#f5f6fb;color:var(--ink);font:14px Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}a{color:inherit;text-decoration:none}
    .layout{min-height:100vh;display:grid;grid-template-columns:248px minmax(0,1fr)}.sidebar{background:#171a35;color:#fff;padding:27px 18px;display:flex;flex-direction:column;gap:36px}.brand{display:flex;align-items:center;gap:12px;padding:0 10px}.brand-mark{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,#766dff,#5cb6ff);display:grid;place-items:center;font-weight:900;font-size:18px;box-shadow:0 8px 22px #5550c444}.brand b{font-size:16px;letter-spacing:.4px}.brand small{display:block;color:#a8acc7;margin-top:3px;font-size:11px}.nav-label{padding:0 12px;margin-bottom:10px;color:#8288aa;font-size:10px;font-weight:800;letter-spacing:1.4px;text-transform:uppercase}.nav-link{display:flex;align-items:center;gap:12px;padding:12px;border-radius:11px;color:#c7c9dc;font-weight:600}.nav-link.active{background:#ffffff16;color:#fff}.nav-icon{width:24px;text-align:center;font-size:16px}.side-bottom{margin-top:auto;padding:15px 12px;border-top:1px solid #ffffff18;color:#a8acc7;font-size:12px;line-height:1.6}
    .main{min-width:0;padding:28px clamp(18px,4vw,52px) 50px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:30px}.crumb{color:var(--muted);font-size:13px}.crumb strong{color:var(--ink)}.account-top{display:flex;align-items:center;gap:10px}.mini-avatar{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#e9e8ff;color:#4b45c4;font-weight:800}.top-name{font-size:13px;font-weight:700}.top-handle{display:block;margin-top:3px;color:var(--muted);font-size:11px}.logout{margin-left:8px;color:#69728a;font-size:13px;font-weight:700}.logout:hover{color:#d54857}
    .hero{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:20px;padding:27px 30px;margin-bottom:21px;border-radius:18px;background:linear-gradient(115deg,#514bd3,#716af2 58%,#478de3);color:white;box-shadow:0 16px 36px #5b55e72b}.hero:after{content:"";position:absolute;width:230px;height:230px;border:1px solid #ffffff24;border-radius:50%;right:7%;top:-135px;box-shadow:0 0 0 28px #ffffff0a,0 0 0 58px #ffffff08}.hero-text{position:relative;z-index:1}.eyebrow{font-size:10px;font-weight:800;letter-spacing:1.3px;text-transform:uppercase;color:#dedcff}.hero h1{margin:8px 0;font-size:clamp(24px,3vw,32px);letter-spacing:-.8px}.hero p{margin:0;color:#e4e5ff;font-size:13px}.hero-avatar{position:relative;z-index:1;width:68px;height:68px;border:2px solid #ffffff9c;border-radius:22px;display:grid;place-items:center;background:#ffffff24;font-size:22px;font-weight:800;box-shadow:0 12px 25px #25207c25}
    .notice{padding:13px 16px;border-radius:11px;background:#eaf8f2;border:1px solid #ccefe0;color:#147454;margin-bottom:19px;font-size:13px;line-height:1.5}.columns{display:grid;grid-template-columns:minmax(0,1.65fr) minmax(230px,.85fr);gap:18px;align-items:start}.panel{background:white;border:1px solid #edf0f6;border-radius:16px;box-shadow:var(--shadow);overflow:hidden}.panel-head{padding:20px 22px;border-bottom:1px solid var(--line)}.panel-head h2{margin:0;font-size:16px;letter-spacing:-.2px}.panel-head p{margin:5px 0 0;color:var(--muted);font-size:12px}.form-body{padding:21px 22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.field{display:grid;gap:7px}.field.full{grid-column:1/-1}.field label{font-size:11px;font-weight:800;color:#566078}.field input,.field select,.field textarea{width:100%;border:1px solid #e0e4ee;border-radius:9px;padding:11px 12px;color:var(--ink);font:inherit;font-size:13px;background:white;outline:none;transition:.16s}.field textarea{resize:vertical;min-height:88px}.field input:focus,.field select:focus,.field textarea:focus{border-color:#a8a3ff;box-shadow:0 0 0 3px #5b55e712}.field input:disabled{background:#f7f8fb;color:#7d8599}.hint{color:#9aa2b5;font-size:10px;font-weight:500}.form-actions{display:flex;justify-content:flex-end;margin-top:19px}.btn{border:0;border-radius:9px;padding:11px 15px;font:inherit;font-weight:750;cursor:pointer;transition:.16s}.btn:hover{transform:translateY(-1px)}.btn-primary{background:var(--purple);color:white;box-shadow:0 7px 16px #5b55e72b}.btn-soft{background:#efefff;color:#514bd3}.btn-danger{background:#fff0f0;color:#c83c4b}.side-stack{display:grid;gap:15px}.side-card{padding:19px}.side-card h3{font-size:14px;margin:0 0 7px}.side-card p{font-size:11px;line-height:1.6;color:var(--muted);margin:0 0 14px}.wa-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:12px;background:#e8f8ef;color:#16865e;font-size:19px;margin-bottom:14px}.danger-card{border-color:#f3e8e9}.danger-card h3{color:#a83240}.delete-confirm{margin-top:13px;padding-top:14px;border-top:1px solid #f0e6e7}.delete-confirm summary{color:#c13b49;font-size:11px;font-weight:750;cursor:pointer}.delete-confirm p{margin:9px 0}.delete-confirm button{width:100%}.footnote{margin-top:16px;color:#a0a7b6;font-size:10px;line-height:1.6}
    @media(max-width:950px){.layout{grid-template-columns:76px minmax(0,1fr)}.sidebar{padding:24px 10px}.brand{justify-content:center;padding:0}.brand-copy,.nav-label,.nav-text,.side-bottom{display:none}.nav-link{justify-content:center;padding:13px 8px}.nav-icon{font-size:18px}}
    @media(max-width:700px){.layout{display:block}.sidebar{height:auto;padding:12px 16px;flex-direction:row;align-items:center;justify-content:space-between;gap:10px}.brand{justify-content:flex-start}.nav-link{padding:10px}.main{padding:20px 14px 35px}.topbar{margin-bottom:22px}.columns{grid-template-columns:1fr}.hero{padding:23px 20px}.hero-avatar{width:56px;height:56px;border-radius:18px}.grid{grid-template-columns:1fr}.field.full{grid-column:auto}.account-top .top-name{display:none}}
  </style>
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand"><div class="brand-mark">A</div><div class="brand-copy"><b>ASTS</b><small>USER SPACE</small></div></div>
    <div><div class="nav-label">Menu utama</div><a class="nav-link active" href="/ujian_asts/index.php"><span class="nav-icon">♙</span><span class="nav-text">Profil saya</span></a></div>
    <div class="side-bottom">Akun pribadi ASTS<br>Data Anda dikelola oleh Anda.</div>
  </aside>
  <main class="main">
    <header class="topbar"><div class="crumb">ASTS <span> / </span> <strong>Profil saya</strong></div><div class="account-top"><div class="mini-avatar"><?= e($initials) ?></div><div class="top-name"><?= e($user['name']) ?><span class="top-handle">@<?= e($user['username']) ?></span></div><a class="logout" href="/ujian_asts/logout.php">Keluar</a></div></header>
    <section class="hero"><div class="hero-text"><div class="eyebrow">Ruang akun ASTS</div><h1>Halo, <?= e($user['name']) ?>!</h1><p>Kelola informasi profil dan nomor WhatsApp Anda di sini.</p></div><div class="hero-avatar"><?= e($initials) ?></div></section>
    <?php if ($notice): ?><div class="notice"><?= e($notice) ?></div><?php endif; ?>
    <div class="columns">
      <section class="panel"><header class="panel-head"><h2>Informasi profil</h2><p>Perubahan hanya berlaku untuk akun Anda.</p></header>
        <form action="/ujian_asts/edit.php" method="post" class="form-body"><div class="grid">
          <div class="field"><label for="name">Nama lengkap</label><input id="name" name="name" maxlength="100" value="<?= e($user['name']) ?>" required></div>
          <div class="field"><label for="username">Username</label><input id="username" value="<?= e($user['username']) ?>" disabled><span class="hint">Username tidak dapat diubah.</span></div>
          <div class="field"><label for="nisn">NISN</label><input id="nisn" name="nisn" maxlength="20" value="<?= e($user['nisn']) ?>" required></div>
          <div class="field"><label for="ttl">Tempat, tanggal lahir</label><input id="ttl" name="ttl" maxlength="100" value="<?= e($user['ttl']) ?>" required></div>
          <div class="field"><label for="gender">Jenis kelamin</label><select id="gender" name="gender" required><option value="Laki-laki" <?= $user['gender']==='Laki-laki'?'selected':'' ?>>Laki-laki</option><option value="Perempuan" <?= $user['gender']==='Perempuan'?'selected':'' ?>>Perempuan</option></select></div>
          <div class="field"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="100" value="<?= e($user['email']) ?>" required></div>
          <div class="field full"><label for="phone">Nomor WhatsApp</label><input id="phone" type="tel" name="phone" value="<?= e($user['phone'] ?? '') ?>" placeholder="6281234567890" required><span class="hint">Gunakan nomor yang aktif menerima WhatsApp.</span></div>
          <div class="field full"><label for="address">Alamat</label><textarea id="address" name="address" required><?= e($user['address']) ?></textarea></div>
          <div class="field full"><label for="password">Password baru <span class="hint">(kosongkan jika tidak diubah)</span></label><input id="password" type="password" name="password" minlength="8" autocomplete="new-password" placeholder="Minimal 8 karakter"></div>
        </div><div class="form-actions"><button class="btn btn-primary" type="submit">Simpan perubahan</button></div></form>
      </section>
      <aside class="side-stack">
        <section class="panel side-card"><div class="wa-icon">◉</div><h3>Pesan WhatsApp</h3><p>Kirim ulang pesan informasi akun ke nomor WhatsApp yang tersimpan di profil Anda.</p><form action="/ujian_asts/kirim_pesan.php" method="post"><button class="btn btn-soft" type="submit">Kirim ulang pesan</button></form></section>
        <section class="panel side-card danger-card"><h3>Hapus akun</h3><p>Menghapus akun akan menghapus profil Anda secara permanen.</p><details class="delete-confirm"><summary>Saya ingin menghapus akun</summary><p>Anda akan keluar setelah akun dihapus.</p><form action="/ujian_asts/hapus.php" method="post" onsubmit="return confirm('Yakin ingin menghapus akun ini secara permanen?')"><button class="btn btn-danger" type="submit">Hapus akun saya</button></form></details></section>
      </aside>
    </div>
    <div class="footnote">ASTS · Ruang akun pribadi. Informasi profil hanya dapat diubah oleh pemilik akun.</div>
  </main>
</div>
</body>
</html>
