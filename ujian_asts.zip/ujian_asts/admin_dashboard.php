<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /ujian_asts/login.php'); exit; }
if (($_SESSION['role'] ?? 'user') !== 'admin') { header('Location: /ujian_asts/index.php'); exit; }
require_once __DIR__ . '/koneksi.php';
$id = (int)$_SESSION['user_id'];
$auth = $conn->prepare('SELECT role FROM users WHERE id=?');
$auth->bind_param('i', $id);
$auth->execute();
if (($auth->get_result()->fetch_assoc()['role'] ?? '') !== 'admin') {
    session_unset(); session_destroy(); header('Location: /ujian_asts/login.php'); exit;
}
$total = (int)$conn->query('SELECT COUNT(*) AS n FROM users')->fetch_assoc()['n'];
$admins = (int)$conn->query("SELECT COUNT(*) AS n FROM users WHERE role='admin'")->fetch_assoc()['n'];
$members = (int)$conn->query("SELECT COUNT(*) AS n FROM users WHERE role<>'admin'")->fetch_assoc()['n'];
$result = $conn->query('SELECT id,name,username,email,phone,gender,role FROM users ORDER BY id DESC');
$adminNotice = $_SESSION['admin_notice'] ?? '';
unset($_SESSION['admin_notice']);
function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function initials($name) {
    $parts = preg_split('/\s+/', trim((string)$name));
    return strtoupper(substr($parts[0] ?? '?', 0, 1) . (count($parts) > 1 ? substr(end($parts), 0, 1) : ''));
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard Admin | ASTS</title>
  <style>
    :root{--ink:#172033;--muted:#77819a;--line:#e8ebf3;--purple:#5b55e7;--purple-soft:#f0efff;--green:#15966a;--shadow:0 18px 48px rgba(29,38,75,.07)}
    *{box-sizing:border-box}body{margin:0;background:#f5f6fb;color:var(--ink);font:14px Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}a{color:inherit;text-decoration:none}
    .layout{min-height:100vh;display:grid;grid-template-columns:248px minmax(0,1fr)}
    .sidebar{background:#171a35;color:#fff;padding:27px 18px;display:flex;flex-direction:column;gap:36px}.brand{display:flex;align-items:center;gap:12px;padding:0 10px}.brand-mark{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,#766dff,#5cb6ff);display:grid;place-items:center;font-weight:900;font-size:18px;box-shadow:0 8px 22px #5550c444}.brand b{font-size:16px;letter-spacing:.4px}.brand small{display:block;color:#a8acc7;margin-top:3px;font-size:11px}.nav-label{padding:0 12px;margin-bottom:10px;color:#8288aa;font-size:10px;font-weight:800;letter-spacing:1.4px;text-transform:uppercase}.nav-link{display:flex;align-items:center;gap:12px;padding:12px;border-radius:11px;color:#c7c9dc;font-weight:600}.nav-link.active{background:#ffffff16;color:white}.nav-icon{width:24px;text-align:center;font-size:16px}.side-bottom{margin-top:auto;padding:15px 12px;border-top:1px solid #ffffff18;color:#a8acc7;font-size:12px;line-height:1.6}
    .main{min-width:0;padding:28px clamp(18px,4vw,52px) 50px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:35px}.breadcrumb{color:var(--muted);font-size:13px}.breadcrumb strong{color:var(--ink)}.admin-user{display:flex;align-items:center;gap:11px}.admin-avatar{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#e9e8ff;color:#4b45c4;font-weight:800}.admin-name{font-size:13px;font-weight:700}.admin-role{display:block;margin-top:3px;color:var(--muted);font-size:11px}.logout{margin-left:9px;color:#69728a;font-size:13px;font-weight:700}.logout:hover{color:#d54857}
    .welcome{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:25px}.welcome h1{font-size:clamp(25px,3vw,34px);letter-spacing:-1px;margin:0 0 8px}.welcome p{margin:0;color:var(--muted)}.date{color:var(--muted);font-size:12px;background:white;border:1px solid var(--line);padding:10px 13px;border-radius:10px;white-space:nowrap}
    .stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:17px;margin-bottom:23px}.stat{position:relative;overflow:hidden;background:white;border:1px solid #edf0f6;border-radius:16px;padding:20px 21px;box-shadow:var(--shadow)}.stat-top{display:flex;align-items:center;justify-content:space-between;color:var(--muted);font-weight:600;font-size:12px}.stat-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:12px;font-size:17px}.stat-icon.violet{background:#efedff;color:#625be7}.stat-icon.blue{background:#e9f4ff;color:#4386d2}.stat-icon.green{background:#e7f8f1;color:#15966a}.stat strong{display:block;margin-top:12px;font-size:30px;letter-spacing:-1px}.stat-hint{margin-top:5px;color:#9aa2b5;font-size:11px}
    .panel{background:white;border:1px solid #edf0f6;border-radius:17px;box-shadow:var(--shadow);overflow:hidden}.panel-head{padding:21px 23px;display:flex;align-items:center;justify-content:space-between;gap:18px;border-bottom:1px solid var(--line)}.panel-title h2{margin:0;font-size:17px;letter-spacing:-.3px}.panel-title p{margin:5px 0 0;color:var(--muted);font-size:12px}.tools{display:flex;gap:9px;align-items:center}.search{position:relative}.search span{position:absolute;left:12px;top:9px;color:#9aa2b5}.search input,.tools select{height:37px;border:1px solid var(--line);border-radius:9px;background:#fff;color:var(--ink);font:inherit;font-size:12px;outline:none}.search input{width:220px;padding:0 12px 0 34px}.tools select{padding:0 30px 0 11px}.search input:focus,.tools select:focus{border-color:#aaa6ff;box-shadow:0 0 0 3px #5b55e712}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:760px}th{padding:12px 20px;background:#fafbfe;text-align:left;color:#929bb0;text-transform:uppercase;font-size:10px;letter-spacing:.8px;font-weight:800}td{padding:14px 20px;border-top:1px solid #f0f2f7;color:#515b72;font-size:12px}tbody tr:hover{background:#fbfbff}.person{display:flex;align-items:center;gap:11px}.person-avatar{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:#f0efff;color:#5751d4;font-size:11px;font-weight:800}.person-name{color:var(--ink);font-size:12px;font-weight:700}.person-id{color:#9aa2b5;font-size:10px;margin-top:3px}.username{color:#5a55cc;font-weight:700}.role{display:inline-flex;align-items:center;gap:6px;border-radius:99px;padding:5px 9px;font-size:10px;font-weight:800}.role.admin{background:#f0efff;color:#5751c9}.role.user{background:#eaf8f2;color:#16805d}.role-dot{width:5px;height:5px;border-radius:50%;background:currentColor}.empty{display:none;text-align:center;padding:40px;color:var(--muted)}.panel-foot{padding:13px 21px;border-top:1px solid var(--line);color:#9aa2b5;font-size:11px}
    .notifications{margin-bottom:22px;background:white;border:1px solid #edf0f6;border-radius:17px;box-shadow:var(--shadow);overflow:hidden}.notify-head{padding:19px 22px;display:flex;justify-content:space-between;align-items:center;gap:14px;border-bottom:1px solid var(--line)}.notify-title{display:flex;align-items:center;gap:10px}.notify-title h2{font-size:16px;margin:0}.notify-count{min-width:22px;height:22px;padding:0 7px;border-radius:99px;background:#fce9eb;color:#c13d4a;display:grid;place-items:center;font-size:10px;font-weight:800}.notify-action{border:0;background:none;color:#5b55d6;font:inherit;font-size:11px;font-weight:750;cursor:pointer}.notify-list{list-style:none;margin:0;padding:0;max-height:300px;overflow:auto}.notify-item{display:grid;grid-template-columns:36px 1fr auto;gap:12px;align-items:center;padding:13px 22px;border-bottom:1px solid #f0f2f7}.notify-item:last-child{border-bottom:0}.notify-item.unread{background:#fafaff}.notify-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:11px;background:#efefff;color:#5b55d6;font-size:14px}.notify-main{font-size:12px;color:#68728a;line-height:1.5}.notify-main strong{color:var(--ink)}.notify-main p{margin:2px 0 0;color:#929bb0;font-size:11px}.notify-time{color:#a0a7b6;font-size:10px;white-space:nowrap}.notify-empty{padding:24px;text-align:center;color:#9aa2b5;font-size:12px}.flash{padding:12px 16px;margin:-8px 0 20px;border:1px solid #ccefe0;border-radius:11px;background:#eaf8f2;color:#147454;font-size:12px;line-height:1.5}.row-actions{display:flex;gap:7px;align-items:center}.row-actions a,.row-actions button{display:inline-block;border:0;border-radius:7px;padding:7px 9px;font:inherit;font-size:10px;font-weight:800;cursor:pointer;text-decoration:none}.edit-link{background:#efefff;color:#514bd3}.delete-button{background:#fff0f0;color:#bf3948}.pagination{display:flex;align-items:center;gap:6px}.page-btn{min-width:30px;height:30px;padding:0 8px;border:1px solid var(--line);border-radius:8px;background:#fff;color:#69728a;font:inherit;font-size:11px;cursor:pointer}.page-btn.active{border-color:#5b55e7;background:#5b55e7;color:#fff}.page-btn:disabled{opacity:.4;cursor:default}.page-info{margin-right:7px;color:#929bb0;font-size:11px}
    @media(max-width:900px){.layout{grid-template-columns:76px minmax(0,1fr)}.sidebar{padding:24px 10px}.brand{justify-content:center;padding:0}.brand-copy,.nav-label,.nav-text,.side-bottom{display:none}.nav-link{justify-content:center;padding:13px 8px}.nav-icon{font-size:18px}}
    @media(max-width:650px){.layout{display:block}.sidebar{height:auto;padding:12px 16px;flex-direction:row;align-items:center;justify-content:space-between;gap:10px}.brand{justify-content:flex-start}.nav-label{display:none}.nav-link{padding:10px}.main{padding:22px 15px 35px}.topbar{margin-bottom:25px}.welcome{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr;gap:10px}.stat{padding:16px 18px}.stat strong{font-size:25px}.panel-head{align-items:flex-start;flex-direction:column;padding:18px}.tools{width:100%}.search{flex:1}.search input{width:100%}.tools select{max-width:125px}.admin-name{display:none}.date{white-space:normal}}
  </style>
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand"><div class="brand-mark">A</div><div class="brand-copy"><b>ASTS</b><small>ADMIN CONSOLE</small></div></div>
    <div><div class="nav-label">Menu utama</div><a class="nav-link active" href="/ujian_asts/admin_dashboard.php"><span class="nav-icon">▦</span><span class="nav-text">Dashboard</span></a></div>
    <div class="side-bottom">ASTS User Management<br>Panel administrator</div>
  </aside>
  <main class="main">
    <header class="topbar"><div class="breadcrumb">ASTS <span> / </span> <strong>Dashboard</strong></div><div class="admin-user"><div class="admin-avatar">A</div><div class="admin-name"><?= h($_SESSION['username']) ?><span class="admin-role">Administrator</span></div><a class="logout" href="/ujian_asts/logout.php">Keluar</a></div></header>
    <section class="welcome"><div><h1>Selamat datang, <?= h($_SESSION['username']) ?> 👋</h1><p>Berikut ringkasan akun yang terdaftar di ASTS.</p></div><div class="date" id="today"></div></section>
    <?php if ($adminNotice): ?><div class="flash"><?= h($adminNotice) ?></div><?php endif; ?>
    <section class="stats">
      <article class="stat"><div class="stat-top"><span>Semua akun</span><span class="stat-icon violet">♙</span></div><strong><?= number_format($total) ?></strong><div class="stat-hint">Jumlah akun dalam sistem</div></article>
      <article class="stat"><div class="stat-top"><span>Akun pengguna</span><span class="stat-icon blue">♧</span></div><strong><?= number_format($members) ?></strong><div class="stat-hint">Akun dengan akses profil pribadi</div></article>
      <article class="stat"><div class="stat-top"><span>Administrator</span><span class="stat-icon green">✦</span></div><strong><?= number_format($admins) ?></strong><div class="stat-hint">Akun dengan akses dashboard admin</div></article>
    </section>
    <section class="notifications"><header class="notify-head"><div class="notify-title"><h2>Notifikasi aktivitas</h2><span class="notify-count" id="unreadCount">0</span></div><form action="/ujian_asts/admin_notifications_read.php" method="post"><button class="notify-action" type="submit">Tandai semua dibaca</button></form></header><ul class="notify-list" id="notificationList"><li class="notify-empty">Memuat notifikasi…</li></ul></section>
    <section class="panel">
      <div class="panel-head"><div class="panel-title"><h2>Daftar akun</h2><p>Informasi akun yang tersimpan di database.</p></div><div class="tools"><label class="search"><span>⌕</span><input type="search" id="searchUsers" placeholder="Cari nama, username, email..."></label><select id="roleFilter"><option value="all">Semua role</option><option value="user">Pengguna</option><option value="admin">Admin</option></select></div></div>
      <div class="table-wrap"><table><thead><tr><th>Pengguna</th><th>Username</th><th>Email</th><th>Nomor WhatsApp</th><th>Gender</th><th>Role</th><th>Aksi</th></tr></thead><tbody id="userRows">
      <?php while ($user = $result->fetch_assoc()): $role = $user['role'] ?? 'user'; ?><tr data-role="<?= h($role) ?>" data-search="<?= h(strtolower(($user['name'] ?? '') . ' ' . ($user['username'] ?? '') . ' ' . ($user['email'] ?? '') . ' ' . ($user['phone'] ?? ''))) ?>"><td><div class="person"><div class="person-avatar"><?= h(initials($user['name'])) ?></div><div><div class="person-name"><?= h($user['name']) ?></div><div class="person-id">ID #<?= (int)$user['id'] ?></div></div></div></td><td class="username"><?= h($user['username'] ?? '-') ?></td><td><?= h($user['email']) ?></td><td><?= h($user['phone'] ?? '-') ?></td><td><?= h($user['gender']) ?></td><td><span class="role <?= h($role) ?>"><i class="role-dot"></i><?= $role === 'admin' ? 'Admin' : 'Pengguna' ?></span></td><td><?php if ($role === 'user'): ?><div class="row-actions"><a class="edit-link" href="/ujian_asts/admin_edit_user.php?id=<?= (int)$user['id'] ?>">Edit</a><form action="/ujian_asts/admin_delete_user.php" method="post" onsubmit="return confirm('Hapus akun <?= h($user['username'] ?? '') ?>? Pesan WhatsApp akan dikirim jika berhasil.')"><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><button class="delete-button" type="submit">Hapus</button></form></div><?php else: ?><span class="muted">—</span><?php endif; ?></td></tr><?php endwhile; ?>
      </tbody></table><div class="empty" id="emptyState">Tidak ada akun yang cocok dengan pencarian.</div></div>
      <footer class="panel-foot" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><span id="shownCount">Menampilkan <?= min(5,$total) ?> dari <?= number_format($total) ?> akun</span><div class="pagination" id="pagination"></div></footer>
    </section>
  </main>
</div>
<script>
  const search = document.getElementById('searchUsers');
  const filter = document.getElementById('roleFilter');
  const rows = [...document.querySelectorAll('#userRows tr')];
  const perPage = 5;
  let currentPage = 1;
  function updateRows() {
    const term = search.value.trim().toLowerCase();
    const role = filter.value;
    const filtered = rows.filter(row => row.dataset.search.includes(term) && (role === 'all' || row.dataset.role === role));
    const pages = Math.max(1, Math.ceil(filtered.length / perPage));
    currentPage = Math.min(currentPage, pages);
    const first = (currentPage - 1) * perPage;
    rows.forEach(row => row.style.display = 'none');
    filtered.slice(first, first + perPage).forEach(row => row.style.display = '');
    document.getElementById('shownCount').textContent = filtered.length ? `Menampilkan ${first + 1}-${Math.min(first + perPage, filtered.length)} dari ${filtered.length} akun` : 'Tidak ada akun';
    document.getElementById('emptyState').style.display = filtered.length ? 'none' : 'block';
    const pagination = document.getElementById('pagination');
    pagination.replaceChildren();
    if (pages <= 1) return;
    const prev = document.createElement('button'); prev.className='page-btn'; prev.textContent='‹'; prev.disabled=currentPage===1; prev.onclick=()=>{currentPage--;updateRows();}; pagination.append(prev);
    for(let page=1;page<=pages;page++) { const button=document.createElement('button'); button.className='page-btn'+(page===currentPage?' active':''); button.textContent=page; button.onclick=()=>{currentPage=page;updateRows();}; pagination.append(button); }
    const next = document.createElement('button'); next.className='page-btn'; next.textContent='›'; next.disabled=currentPage===pages; next.onclick=()=>{currentPage++;updateRows();}; pagination.append(next);
  }
  search.addEventListener('input', () => {currentPage=1;updateRows();});
  filter.addEventListener('change', () => {currentPage=1;updateRows();});
  updateRows();
  document.getElementById('today').textContent = new Intl.DateTimeFormat('id-ID', {weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date());
  const notificationList = document.getElementById('notificationList');
  function safeText(tag, className, value) { const node=document.createElement(tag); if(className) node.className=className; node.textContent=value; return node; }
  async function loadNotifications() {
    try {
      const response = await fetch('/ujian_asts/admin_notifications.php?t=' + Date.now(), {cache:'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      document.getElementById('unreadCount').textContent = data.unread;
      notificationList.replaceChildren();
      if (!data.items.length) { notificationList.append(safeText('li','notify-empty','Belum ada aktivitas pengguna.')); return; }
      data.items.forEach(item => {
        const row = document.createElement('li'); row.className='notify-item' + (Number(item.is_read) ? '' : ' unread');
        const icon = safeText('span','notify-icon', item.action === 'register' ? '+' : item.action.includes('edit') ? '✎' : '×');
        const body = document.createElement('div'); body.className='notify-main';
        const title = document.createElement('div'); const strong=safeText('strong','',item.actor_name + ' (@' + item.actor_username + ')');
        title.append(strong, document.createTextNode(' ' + item.message)); body.append(title);
        const date = new Date(item.created_at.replace(' ', 'T') + 'Z');
        body.append(safeText('p','',new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short'}).format(date)));
        row.append(icon,body); notificationList.append(row);
      });
    } catch (error) { notificationList.replaceChildren(safeText('li','notify-empty','Notifikasi belum dapat dimuat.')); }
  }
  loadNotifications();
  window.setInterval(loadNotifications, 15000);
</script>
</body>
</html>
