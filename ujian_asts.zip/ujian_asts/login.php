<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: ' . (($_SESSION['role'] ?? 'user') === 'admin' ? '/ujian_asts/admin_dashboard.php' : '/ujian_asts/index.php'));
    exit;
}

$error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | ASTS User Management</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, #dbeafe, transparent 35%),
                radial-gradient(circle at bottom right, #e0e7ff, transparent 35%),
                #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            width: 100%;
            max-width: 430px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.88);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,.8);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 25px 70px rgba(15, 23, 42, .12);
        }

        .logo {
            width: 70px;
            height: 70px;
            margin: 0 auto 22px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: white;
            font-size: 30px;
            font-weight: bold;
            box-shadow: 0 12px 30px rgba(37, 99, 235, .25);
        }

        h1 {
            text-align: center;
            font-size: 28px;
            color: #111827;
            margin-bottom: 8px;
        }

        .subtitle {
            text-align: center;
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            color: #374151;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #dbe1ea;
            border-radius: 12px;
            outline: none;
            font-size: 14px;
            transition: .2s;
            background: #fff;
        }

        input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, .1);
        }

        .login-button {
            width: 100%;
            border: none;
            border-radius: 12px;
            padding: 15px;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: .2s;
            margin-top: 5px;
        }

        .login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(37, 99, 235, .25);
        }

        .error {
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #be123c;
            padding: 12px 14px;
            border-radius: 10px;
            font-size: 13px;
            margin-bottom: 20px;
        }

        .footer {
            text-align: center;
            margin-top: 25px;
            color: #9ca3af;
            font-size: 12px;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 28px 22px;
            }
        }
    </style>
</head>

<body>

<div class="login-container">

    <div class="login-card">

        <div class="logo">
            A
        </div>

        <h1>Selamat Datang</h1>

        <p class="subtitle">
            Login untuk mengakses Dashboard ASTS
        </p>

        <?php if ($error): ?>
            <div class="error">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form action="/ujian_asts/proses_login.php" method="POST">

            <div class="form-group">
                <label for="username">
                    Username
                </label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Masukkan username"
                    required
                    autocomplete="username"
                >
            </div>

            <div class="form-group">
                <label for="password">
                    Password
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                    autocomplete="current-password"
                >
            </div>

            <button
                type="submit"
                class="login-button"
            >
                Login ke Dashboard
            </button>

        </form>

        <p style="text-align:center;margin-top:20px;color:#6b7280;font-size:14px;">
            Belum punya akun? <a href="/ujian_asts/register.php">Daftar sekarang</a>
        </p>

        <div class="footer">
            ASTS MPKK RPL • User Management
        </div>

    </div>

</div>

</body>
</html>
